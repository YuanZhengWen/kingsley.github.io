---
layout: archive
title: "CV"
permalink: /cv/
author_profile: true
redirect_from:
  - /resume
---

{% include base_path %}

Education
======
* B.S. in Chengdu University of Technology, 2018-Present

Research experience
======
* 2019 Fall-Present: Research Assistant
  * Chengdu University of Technology
  * Research Topic: Investgations of Inospheric and Magnetospheric Anomalies before Strong Earthquakes
  * Duties included: PI
  * Supervisor: Dr.Dan Tao
* 2020 Summer: Research Assistant
  * National Space Sciences Center,Chinese Academy of Sciences (CAS)

  
Skills
======
Programming Skills:
* C(Basic)
* Matlab(Intermediate) in progress
* Python(Basic) in progress
* IDL(Basic) in Progress

Language Skills:
* Sichuan Dialect
* Madarin
* English
* Cantonese


Publications
======
  None
  
Talks
======
* 2019 Fall: Research Project Brief Report and Presentation,School of Geophysics,Chengdu University of Technology
  
Teaching
======
* 2019 Spring,2019 Fall:Teaching Assitant
* Subject：College Physics
* Professor:Dr.Huajun Wang
  
Awards
======
* Second Prize in Mathematical Competitions for Collge Students, Chinese Mathematical Society (CMS)

Service and leadership
======
* Currently signed in to 43 different slack teams
