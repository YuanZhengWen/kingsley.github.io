---
permalink: /
title: "About me"
excerpt: "About me"
author_profile: true
redirect_from: 
  - /about/
  - /about.html
---
 Welcome to my homepage! I am Yuanzheng(Kingsley) Wen, currently an undergraduate student at Department of Geophysics and Space Sciences,School of Geophysics,Chengdu University of Technology,China.
 
 I will try to keep my website frequently updated and make it better!



